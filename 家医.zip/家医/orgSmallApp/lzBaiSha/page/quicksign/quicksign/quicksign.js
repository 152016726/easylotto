// page/quicksign/quicksign/quicksign.js
const app = getApp()
const util = require('../../../utils/util.js');
const address = require('../../../utils/address.js');
Page({
    data: {
        userInfo: {},
        code: '',
        region: [],
        provinces: [],
        cities: [],
        areas: [],
        province: {
          name: '--省--',
          id: ''
        },
        city: {
          name: '--市--',
          id: ''
        },
        area: {
          name: '--区--',
          id: ''
        },
        addressArray: [['--省--'], ['--市--'], ['--区--']],
        addressIndex: [0, 0, 0],
        ifForm: false,
        sendText: '发送验证码',
        ifSelectAddress: true,
        readChecked:false,  //签约协议未读状态
        signbtnDisabled:true, //签约协议按钮不可点击
    },
 
   /**
    * 生命周期函数--监听页面加载
    */
    onLoad: function (options) {
 
    },
    //姓名
    nameInputTap: function (e) {
        var _this = this;
        var userInfo = _this.data.userInfo;
        if (e.detail.value) {
            userInfo.userName = e.detail.value;
            _this.setData({
                userInfo: userInfo,
                nameTip: ''
            })
        } else {
            _this.setData({
                nameTip: '姓名不能为空'
            })
        }
    },
    //身份证
    idCardCheckTap: function (e) {
        var _this = this;
        //e.detail.value,identityCodeValid
        console.log('----------------')
        console.log(e.detail.value)
        var jsonObj = util.identityCodeValid(e.detail.value);
        var userInfo = _this.data.userInfo;
        // userInfo.age = jsonObj.more.age;
        // userInfo.agent = jsonObj.more.sex == "女" ? 2 : 1;
        console.log(jsonObj)
        if (jsonObj.pass) {
            console.log('idCard pass')
            userInfo.idCard = e.detail.value;
            _this.setData({
                userInfo: userInfo,
                idCardTip: ''
            })
        } else {
            console.log('idCard nopass')
            _this.setData({
                idCardTip: jsonObj.tip
            })
        }
    },
    //手机号
    phoneInputTap: function (e) {
        var _this = this;
        var phoneReg = /^[1][3,4,5,7,8][0-9]{9}$/;
        var mobile = e.detail.value;
        if (phoneReg.test(mobile)) {
            var userInfo = _this.data.userInfo;
            userInfo.userMobile = mobile;
            _this.setData({
                userInfo: userInfo,
                phoneTip: ''
            })
        } else {
            _this.setData({
                phoneTip: '请输入正确的手机号'
            })
        }
    },
    //发送验证码
    sendCodeTap: function (e) {
        var _this = this;
        var mobile = _this.data.userInfo.userMobile;
        var phoneReg = /^[1][3,4,5,7,8][0-9]{9}$/;
        if (phoneReg.test(mobile)) {
            var wait = 60;
            function time(o) {
                if (wait == 0) {
                    _this.setData({
                        sendText: '发送验证码'
                })
                wait = 60;
                } else {
                    _this.setData({
                        sendText: '' + wait + 's后重发'
                    })
                    wait--;
                    setTimeout(function () {
                       time(o)
                    },1000)
                }
            }
            time(e)
            _this.setData({
                phoneTip: ''
            })
            app.request({
                url: '/message/insert',
                header: {
                  'content-type': 'application/json'
                },
                data: {   
                    message: {
                        mobile: mobile
                    }
                },
                method: "GET",
                success: function (res) {
                    if (res.code == 1) {
                        wx.showToast({
                            title: '信息已发送',
                            icon: 'none',
                            duration: 2000
                        })
                    } else {
                        wx.showToast({
                            title: res.message,
                            icon: 'none',
                            duration: 2000
                        })
                    }
                }
            })
        } else {
            _this.setData({
                phoneTip: '请输入正确的手机号'
            })
        }
    },
    //验证码
    codeInputTap: function (e) {
        var _this = this;
        if (e.detail.value) {
            _this.setData({
                code: e.detail.value,
                codeTip: ''
            })
        } else {
            _this.setData({
                codeTip: '验证码不能为空'
            })
        }
    },
    //选择地址
    bindcolumnRegionchange: function (e) {
        var _this = this;
        address.selectAddress(_this, e)
    },
    //详细地址
    addressTap: function (e) {
        var _this = this;
        var userInfo = _this.data.userInfo;
        if (e.detail.value) {
            userInfo.address = e.detail.value;
            _this.setData({
                userInfo: userInfo,
                addressTip: ''
            })
        } else {
            _this.setData({
                addressTip: '地址不能为空'
            })
        }
    },
    //选择服务包
    radioChange: function(e){

    },
    //点击签约协议
    checkboxChange: function(e) {
        console.log(e.detail.value[0])
        var _this=this;
        var readCheckedVal=e.detail.value[0];
        var signbtnDisabled = _this.data.signbtnDisabled;
        if(!readCheckedVal){
            signbtnDisabled=true;
        }else{
            signbtnDisabled=false;
        }
        _this.setData({
            signbtnDisabled:signbtnDisabled,
        })
    },
    //点击签约按钮
    bindSign:function(){
        this.save();
    },
    save: function () {
        var _this = this;
        var userInfo = _this.data.userInfo;
        var provinceId = '';
        var cityId = '';
        var districtId = '';
        provinceId = _this.data.province.id ? _this.data.province.id : '';
        cityId = _this.data.city.id ? _this.data.city.id : '';
        districtId = _this.data.area.id ? _this.data.area.id : '';
        var ifSelectAddress = _this.data.province.id && ((_this.data.city.id && _this.data.area.id) || (JSON.stringify(_this.data.city) == '{}' && JSON.stringify(_this.data.area) == '{}') || (_this.data.city.id && JSON.stringify(_this.data.area) == '{}'));
        _this.setData({
            ifSelectAddress: ifSelectAddress
        })
        _this.data.userInfo.address ? _this.setData({ addressTip: '' }) : _this.setData({ addressTip: '地址不能为空' });
        _this.data.userInfo.userName ? _this.setData({ nameTip: '' }) : _this.setData({ nameTip: '姓名不能为空' });
        _this.data.code ? _this.setData({ codeTip: '' }) : _this.setData({ codeTip: '验证码不能为空' });
        _this.data.userInfo.userMobile ? _this.setData({ phoneTip: '' }) : _this.setData({ phoneTip: '请输入正确的手机号码' });
        _this.data.userInfo.idCard ? _this.setData({ idCardTip: '' }) : _this.setData({ idCardTip: '请输入正确的身份证号' });
        // if (ifSelectAddress && !_this.data.addressTip && !_this.data.nameTip && !_this.data.phoneTip && !_this.data.idCardTip && ((!userInfo.id && !_this.data.codeTip) || userInfo.id)) {
            console.log(_this.data.userInfo)
            console.log({
                "sessionId": _this.data.sessionId,
                "idCard": _this.data.userInfo.idCard,
                "mobile": _this.data.userInfo.userMobile,
                "type": 2,
                "code": _this.data.code,
                "gender": _this.data.userInfo.agent,
                "age": _this.data.userInfo.age,
                "thirdNickname": _this.data.userInfo.userName,
                "headimgurl": _this.data.userInfo.userPic,
                "address": _this.data.userInfo.address,
                "provinceId": provinceId,
                "cityId": cityId,
                "districtId": districtId
            })
        //     app.request({
        //         url: '/user/insertMiniAppSaveInfo',
        //         header: {
        //           'content-type': 'application/json'
        //         },
        //         data: {
        //              params: {
        //                 "sessionId": _this.data.sessionId,
        //                 "idCard": _this.data.userInfo.idCard,
        //                 "mobile": _this.data.userInfo.userMobile,
        //                 "type": 2,
        //                 "code": _this.data.code,
        //                 "gender": _this.data.userInfo.agent,
        //                 "age": _this.data.userInfo.age,
        //                 "thirdNickname": _this.data.userInfo.userName,
        //                 "headimgurl": _this.data.userInfo.userPic,
        //                 "address": _this.data.userInfo.address,
        //                 "provinceId": provinceId,
        //                 "cityId": cityId,
        //                 "districtId": districtId
        //             }
        //         },
        //         method: "GET",
        //         success: function (res) {
        //             if (res.code == 1) {
        //                 _this.setData({
        //                     userInfo: res.obj
        //                 })
        //                 wx.setStorage({
        //                     key: "userInfo",
        //                     data: res.obj
        //                 })
        //                 wx.showToast({
        //                     title: '保存成功',
        //                     icon: 'success',
        //                     duration: 2000,
        //                     success: function (res) {
        //                         wx.navigateBack({
        //                             delta: 1
        //                         })
        //                     }
        //                 });
        //             } else if (res.code == 42007) {
        //                 // 重新登录
        //                 wx.login({
        //                     success: res => {
        //                         var code = res.code;
        //                         var params = {};
        //                         params.code = code;
        //                         // 获取用户信息
        //                         wx.getUserInfo({
        //                             lang: 'zh_CN',
        //                             success: res => {
        //                                 params.thirdNickname = res.userInfo.nickName;
        //                                 params.province = res.userInfo.province;
        //                                 params.city = res.userInfo.city;
        //                                 params.country = res.userInfo.country;
        //                                 params.headimgurl = res.userInfo.avatarUrl;
        //                                 params.sex = res.userInfo.agent;
        //                                 _this.login(params);
        //                             },
        //                             fail: res => {
        //                               _this.login(params);
        //                             }
        //                         })
        //                     }
        //                 })
        //             } else {
        //                 wx.showToast({
        //                     title: res.message,
        //                     icon: 'none',
        //                     duration: 2000
        //                 })
        //             }
        //         }
        //     })
        // }
    },
})