// page/quicksign/signresult/signresult.js
Page({
    data: {
        phoneNumber:15689789562, //地址栏电话号码
        idCard:45786545698789654, //地址栏身份证
    },
 
   /**
    * 生命周期函数--监听页面加载
    */
    onLoad: function (options) {
 
    },
})